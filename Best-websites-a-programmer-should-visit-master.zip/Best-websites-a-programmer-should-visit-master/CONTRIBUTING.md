Hello guys.
For contributions to be approved they should respect this form : 

`* [Site name | A simple description](url) : a simple description of the site or slogan of the site. ` 

kindly.
